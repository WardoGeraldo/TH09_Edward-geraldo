﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH09_Edward_Geraldo
{
    public partial class mainForm : Form
    {
        DataTable dt = new DataTable();
        int price1 = 120000;
        int price2 = 150000;
        int price3 = 170000;
        int totalPrice;
        int totalPrices; //tampungan
        int totals = 0;
        int index = 0;
       
        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            tb_subTotal.Enabled = false;
            tb_total.Enabled = false;
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Item Name");
            dt.Columns.Add("Item Price");
            dt.Columns.Add("Total");
            dgv_total.DataSource = dt;
            this.BackColor = Color.BlueViolet;
        }
       
        int counter = 0;
        private void btn_tshirt1_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black T-Shirt")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    //int total = Convert.ToInt32(row.Cells[3].Value);
                    //row.Cells[3].Value = totalPrices + price1;
                    //totals = Convert.ToInt32(row.Cells[3].Value);
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Black T-Shirt", "Rp 120.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }
        private void btn_tshirt2_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Airism T-Shirt")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Airism T-Shirt", "Rp 150.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();


        }
        private void btn_tshirt3_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "T-Shirt Kerah")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "T-Shirt Kerah", "Rp 170.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shirt1_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Blue Shirt")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Blue Shirt", "Rp 120.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shirt2_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Green Shirt")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Green Shirt", "Rp 150.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shirt3_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Cream Shirt")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals; 
                    break;

                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Cream Shirt", "Rp 170.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shortpant1_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black Pants")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Black Pants", "Rp 120.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shortpant2_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Cream Pants")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Cream Pants", "Rp 150.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shortpant3_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "White Pants")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "White Pants", "Rp 170.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_longPants1_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Long Black Jeans")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)

                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals; 
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Long Black Jeans", "Rp 120.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_longPants2_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Long Jeans")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Long Jeans", "Rp 150.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_longPants3_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Cream Trousers")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Cream Trousers", "Rp 170.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shoe1_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Air Jordan 1")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Air Jordan 1", "Rp 120.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shoe2_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Air Jordan 11")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)

                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals; break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Air Jordan 11", "Rp 150.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_shoe3_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Adidas NMD R1")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Adidas NMD R1", "Rp 170.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_jewel1_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Aesthetic Ring")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Aesthetic Ring", "Rp 120.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_jewel2_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Silver Bracelet")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Silver Bracelet", "Rp 150.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_jewel3_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black Copper Necklace")
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, "Black Copper Necklace", "Rp 170.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_addOthers_Click(object sender, EventArgs e)
        {
            int tax;
            bool itemExists = false;

            foreach (DataGridViewRow row in dgv_total.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == tb_nameOthers.Text)
                {
                    itemExists = true;
                    counter++;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); //currentquantity int buat tampung rowcells[0] yg awalnya 1. 
                    row.Cells[0].Value = currentQuantity + 1; //rowcells[0] itu 1 = currentquantity yg sudah jadi 2 (1+1)
                    totals = Convert.ToInt32(row.Cells[0].Value) * Convert.ToInt32(tb_priceOthers.Text);
                    row.Cells[3].Value = totals; 
                    break;
                }
            }
            if (!itemExists)
            {
                dt.Rows.Add(1, tb_nameOthers.Text, tb_priceOthers.Text, tb_priceOthers.Text);
            }
            totalPrices = totalPrice += (Convert.ToInt32(tb_priceOthers.Text));
            tax = totalPrice / 10;
            tb_subTotal.Text = (totalPrices).ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg; *.png; *.bmp|All Files (.)|*.*";
            ofd.Multiselect = true;
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                pbox_upload.Image = Image.FromFile(ofd.FileName);
                tb_nameOthers.Enabled = true;
                tb_priceOthers.Enabled = true;
            }
        }
        private void tb_priceOthers_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = true;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }
        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = true;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }
        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = true;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }
        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = true;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }
        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = true;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }
        private void jewelrysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = true;
            panel_others.Visible = false;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_others.Visible = true;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
        }

        private void tb_priceOthers_TextChanged(object sender, EventArgs e)
        {
            if(tb_priceOthers.Text == "" && tb_nameOthers.Text == "" )
            {
                btn_addOthers.Enabled = false;
            }
            else
            {
                btn_addOthers.Enabled = true;
            }
        }

        private void dgv_total_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            delete();
            
        }

        private void delete()
        {
            if (index >= 0)
            {
                dt.Rows.RemoveAt(index);
            }
            int tes = 0;
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                tes += Convert.ToInt32(dt.Rows[i][3]); //dt.Rows[i][3] itu column total
            }
            tb_subTotal.Text = tes.ToString();
            tb_total.Text = (tes + tes / 10).ToString();
            totalPrice = tes;
            //else
            //{       
            //    MessageBox.Show("Empty");
            //}
        } 
    }
}
