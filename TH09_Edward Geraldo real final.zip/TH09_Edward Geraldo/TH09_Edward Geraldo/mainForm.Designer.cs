﻿namespace TH09_Edward_Geraldo
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelrysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_total = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_subTotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.btn_tshirt3 = new System.Windows.Forms.Button();
            this.btn_tshirt2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_tshirt1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_shirt3 = new System.Windows.Forms.Button();
            this.btn_shirt2 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btn_shirt1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_shortpant3 = new System.Windows.Forms.Button();
            this.btn_shortpant2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btn_shortpant1 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.panel_longPants = new System.Windows.Forms.Panel();
            this.btn_longPants3 = new System.Windows.Forms.Button();
            this.btn_longPants2 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.btn_longPants1 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_shoe3 = new System.Windows.Forms.Button();
            this.btn_shoe2 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.btn_shoe1 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.panel_jewel = new System.Windows.Forms.Panel();
            this.btn_jewel3 = new System.Windows.Forms.Button();
            this.btn_jewel2 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.btn_jewel1 = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.panel_others = new System.Windows.Forms.Panel();
            this.tb_priceOthers = new System.Windows.Forms.TextBox();
            this.tb_nameOthers = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.btn_upload = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.btn_addOthers = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pbox_upload = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_total)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            this.panel_shirt.SuspendLayout();
            this.panel_pants.SuspendLayout();
            this.panel_longPants.SuspendLayout();
            this.panel_shoes.SuspendLayout();
            this.panel_jewel.SuspendLayout();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_upload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1021, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelrysToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelrysToolStripMenuItem
            // 
            this.jewelrysToolStripMenuItem.Name = "jewelrysToolStripMenuItem";
            this.jewelrysToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.jewelrysToolStripMenuItem.Text = "Jewelrys";
            this.jewelrysToolStripMenuItem.Click += new System.EventHandler(this.jewelrysToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_total
            // 
            this.dgv_total.AllowUserToAddRows = false;
            this.dgv_total.AllowUserToResizeColumns = false;
            this.dgv_total.AllowUserToResizeRows = false;
            this.dgv_total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_total.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_total.Location = new System.Drawing.Point(519, 44);
            this.dgv_total.Name = "dgv_total";
            this.dgv_total.RowHeadersVisible = false;
            this.dgv_total.RowHeadersWidth = 51;
            this.dgv_total.RowTemplate.Height = 24;
            this.dgv_total.Size = new System.Drawing.Size(490, 291);
            this.dgv_total.TabIndex = 1;
            this.dgv_total.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_total_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(525, 355);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sub-Total:";
            // 
            // tb_subTotal
            // 
            this.tb_subTotal.Location = new System.Drawing.Point(659, 358);
            this.tb_subTotal.Name = "tb_subTotal";
            this.tb_subTotal.Size = new System.Drawing.Size(139, 22);
            this.tb_subTotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(659, 395);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(139, 22);
            this.tb_total.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(525, 392);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Total:";
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.btn_tshirt3);
            this.panel_tshirt.Controls.Add(this.btn_tshirt2);
            this.panel_tshirt.Controls.Add(this.label7);
            this.panel_tshirt.Controls.Add(this.label5);
            this.panel_tshirt.Controls.Add(this.label8);
            this.panel_tshirt.Controls.Add(this.label6);
            this.panel_tshirt.Controls.Add(this.pictureBox3);
            this.panel_tshirt.Controls.Add(this.pictureBox2);
            this.panel_tshirt.Controls.Add(this.label4);
            this.panel_tshirt.Controls.Add(this.btn_tshirt1);
            this.panel_tshirt.Controls.Add(this.label3);
            this.panel_tshirt.Controls.Add(this.pictureBox1);
            this.panel_tshirt.Location = new System.Drawing.Point(12, 44);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(477, 291);
            this.panel_tshirt.TabIndex = 7;
            this.panel_tshirt.Visible = false;
            // 
            // btn_tshirt3
            // 
            this.btn_tshirt3.Location = new System.Drawing.Point(348, 220);
            this.btn_tshirt3.Name = "btn_tshirt3";
            this.btn_tshirt3.Size = new System.Drawing.Size(114, 27);
            this.btn_tshirt3.TabIndex = 13;
            this.btn_tshirt3.Text = "Add To Cart";
            this.btn_tshirt3.UseVisualStyleBackColor = true;
            this.btn_tshirt3.Click += new System.EventHandler(this.btn_tshirt3_Click);
            // 
            // btn_tshirt2
            // 
            this.btn_tshirt2.Location = new System.Drawing.Point(175, 220);
            this.btn_tshirt2.Name = "btn_tshirt2";
            this.btn_tshirt2.Size = new System.Drawing.Size(114, 27);
            this.btn_tshirt2.TabIndex = 12;
            this.btn_tshirt2.Text = "Add To Cart";
            this.btn_tshirt2.UseVisualStyleBackColor = true;
            this.btn_tshirt2.Click += new System.EventHandler(this.btn_tshirt2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(369, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Rp 170.000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(196, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Rp 150.000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(362, 181);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "T-Shirt Kerah";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(193, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "Airism T-Shirt";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Rp 120.000";
            // 
            // btn_tshirt1
            // 
            this.btn_tshirt1.Location = new System.Drawing.Point(6, 220);
            this.btn_tshirt1.Name = "btn_tshirt1";
            this.btn_tshirt1.Size = new System.Drawing.Size(114, 27);
            this.btn_tshirt1.TabIndex = 4;
            this.btn_tshirt1.Text = "Add To Cart";
            this.btn_tshirt1.UseVisualStyleBackColor = true;
            this.btn_tshirt1.Click += new System.EventHandler(this.btn_tshirt1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Black T-Shirt";
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.btn_shirt3);
            this.panel_shirt.Controls.Add(this.btn_shirt2);
            this.panel_shirt.Controls.Add(this.label9);
            this.panel_shirt.Controls.Add(this.label10);
            this.panel_shirt.Controls.Add(this.label11);
            this.panel_shirt.Controls.Add(this.label12);
            this.panel_shirt.Controls.Add(this.pictureBox4);
            this.panel_shirt.Controls.Add(this.pictureBox5);
            this.panel_shirt.Controls.Add(this.label13);
            this.panel_shirt.Controls.Add(this.btn_shirt1);
            this.panel_shirt.Controls.Add(this.label14);
            this.panel_shirt.Controls.Add(this.pictureBox6);
            this.panel_shirt.Location = new System.Drawing.Point(12, 44);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(477, 291);
            this.panel_shirt.TabIndex = 14;
            this.panel_shirt.Visible = false;
            // 
            // btn_shirt3
            // 
            this.btn_shirt3.Location = new System.Drawing.Point(348, 220);
            this.btn_shirt3.Name = "btn_shirt3";
            this.btn_shirt3.Size = new System.Drawing.Size(114, 27);
            this.btn_shirt3.TabIndex = 13;
            this.btn_shirt3.Text = "Add To Cart";
            this.btn_shirt3.UseVisualStyleBackColor = true;
            this.btn_shirt3.Click += new System.EventHandler(this.btn_shirt3_Click);
            // 
            // btn_shirt2
            // 
            this.btn_shirt2.Location = new System.Drawing.Point(175, 220);
            this.btn_shirt2.Name = "btn_shirt2";
            this.btn_shirt2.Size = new System.Drawing.Size(114, 27);
            this.btn_shirt2.TabIndex = 12;
            this.btn_shirt2.Text = "Add To Cart";
            this.btn_shirt2.UseVisualStyleBackColor = true;
            this.btn_shirt2.Click += new System.EventHandler(this.btn_shirt2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(369, 201);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 16);
            this.label9.TabIndex = 11;
            this.label9.Text = "Rp 170.000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(196, 201);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Rp 150.000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(369, 181);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 16);
            this.label11.TabIndex = 9;
            this.label11.Text = "Cream Shirt";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(196, 181);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Green Shirt";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 201);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 16);
            this.label13.TabIndex = 5;
            this.label13.Text = "Rp 120.000";
            // 
            // btn_shirt1
            // 
            this.btn_shirt1.Location = new System.Drawing.Point(6, 220);
            this.btn_shirt1.Name = "btn_shirt1";
            this.btn_shirt1.Size = new System.Drawing.Size(114, 27);
            this.btn_shirt1.TabIndex = 4;
            this.btn_shirt1.Text = "Add To Cart";
            this.btn_shirt1.UseVisualStyleBackColor = true;
            this.btn_shirt1.Click += new System.EventHandler(this.btn_shirt1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 181);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 16);
            this.label14.TabIndex = 3;
            this.label14.Text = "Blue Shirt";
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_shortpant3);
            this.panel_pants.Controls.Add(this.btn_shortpant2);
            this.panel_pants.Controls.Add(this.label15);
            this.panel_pants.Controls.Add(this.label16);
            this.panel_pants.Controls.Add(this.label17);
            this.panel_pants.Controls.Add(this.label18);
            this.panel_pants.Controls.Add(this.pictureBox7);
            this.panel_pants.Controls.Add(this.pictureBox8);
            this.panel_pants.Controls.Add(this.label19);
            this.panel_pants.Controls.Add(this.btn_shortpant1);
            this.panel_pants.Controls.Add(this.label20);
            this.panel_pants.Controls.Add(this.pictureBox9);
            this.panel_pants.Location = new System.Drawing.Point(12, 44);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(477, 291);
            this.panel_pants.TabIndex = 15;
            this.panel_pants.Visible = false;
            // 
            // btn_shortpant3
            // 
            this.btn_shortpant3.Location = new System.Drawing.Point(348, 220);
            this.btn_shortpant3.Name = "btn_shortpant3";
            this.btn_shortpant3.Size = new System.Drawing.Size(114, 27);
            this.btn_shortpant3.TabIndex = 13;
            this.btn_shortpant3.Text = "Add To Cart";
            this.btn_shortpant3.UseVisualStyleBackColor = true;
            this.btn_shortpant3.Click += new System.EventHandler(this.btn_shortpant3_Click);
            // 
            // btn_shortpant2
            // 
            this.btn_shortpant2.Location = new System.Drawing.Point(175, 220);
            this.btn_shortpant2.Name = "btn_shortpant2";
            this.btn_shortpant2.Size = new System.Drawing.Size(114, 27);
            this.btn_shortpant2.TabIndex = 12;
            this.btn_shortpant2.Text = "Add To Cart";
            this.btn_shortpant2.UseVisualStyleBackColor = true;
            this.btn_shortpant2.Click += new System.EventHandler(this.btn_shortpant2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(369, 201);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 16);
            this.label15.TabIndex = 11;
            this.label15.Text = "Rp 170.000";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(196, 201);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 16);
            this.label16.TabIndex = 9;
            this.label16.Text = "Rp 150.000";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(369, 181);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 16);
            this.label17.TabIndex = 9;
            this.label17.Text = "White Pants";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(193, 181);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(84, 16);
            this.label18.TabIndex = 7;
            this.label18.Text = "Cream Pants";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(24, 201);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 16);
            this.label19.TabIndex = 5;
            this.label19.Text = "Rp 120.000";
            // 
            // btn_shortpant1
            // 
            this.btn_shortpant1.Location = new System.Drawing.Point(6, 220);
            this.btn_shortpant1.Name = "btn_shortpant1";
            this.btn_shortpant1.Size = new System.Drawing.Size(114, 27);
            this.btn_shortpant1.TabIndex = 4;
            this.btn_shortpant1.Text = "Add To Cart";
            this.btn_shortpant1.UseVisualStyleBackColor = true;
            this.btn_shortpant1.Click += new System.EventHandler(this.btn_shortpant1_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(24, 181);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 16);
            this.label20.TabIndex = 3;
            this.label20.Text = "Black Pants";
            // 
            // panel_longPants
            // 
            this.panel_longPants.Controls.Add(this.btn_longPants3);
            this.panel_longPants.Controls.Add(this.btn_longPants2);
            this.panel_longPants.Controls.Add(this.label21);
            this.panel_longPants.Controls.Add(this.label22);
            this.panel_longPants.Controls.Add(this.label23);
            this.panel_longPants.Controls.Add(this.label24);
            this.panel_longPants.Controls.Add(this.pictureBox10);
            this.panel_longPants.Controls.Add(this.pictureBox11);
            this.panel_longPants.Controls.Add(this.label25);
            this.panel_longPants.Controls.Add(this.btn_longPants1);
            this.panel_longPants.Controls.Add(this.label26);
            this.panel_longPants.Controls.Add(this.pictureBox12);
            this.panel_longPants.Location = new System.Drawing.Point(12, 44);
            this.panel_longPants.Name = "panel_longPants";
            this.panel_longPants.Size = new System.Drawing.Size(493, 291);
            this.panel_longPants.TabIndex = 16;
            this.panel_longPants.Visible = false;
            // 
            // btn_longPants3
            // 
            this.btn_longPants3.Location = new System.Drawing.Point(348, 220);
            this.btn_longPants3.Name = "btn_longPants3";
            this.btn_longPants3.Size = new System.Drawing.Size(114, 27);
            this.btn_longPants3.TabIndex = 13;
            this.btn_longPants3.Text = "Add To Cart";
            this.btn_longPants3.UseVisualStyleBackColor = true;
            this.btn_longPants3.Click += new System.EventHandler(this.btn_longPants3_Click);
            // 
            // btn_longPants2
            // 
            this.btn_longPants2.Location = new System.Drawing.Point(175, 220);
            this.btn_longPants2.Name = "btn_longPants2";
            this.btn_longPants2.Size = new System.Drawing.Size(114, 27);
            this.btn_longPants2.TabIndex = 12;
            this.btn_longPants2.Text = "Add To Cart";
            this.btn_longPants2.UseVisualStyleBackColor = true;
            this.btn_longPants2.Click += new System.EventHandler(this.btn_longPants2_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(369, 201);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 16);
            this.label21.TabIndex = 11;
            this.label21.Text = "Rp 170.000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(196, 201);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(73, 16);
            this.label22.TabIndex = 9;
            this.label22.Text = "Rp 150.000";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(358, 181);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(104, 16);
            this.label23.TabIndex = 9;
            this.label23.Text = "Cream Trousers";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(193, 181);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 16);
            this.label24.TabIndex = 7;
            this.label24.Text = "Long Jeans";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(24, 201);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(73, 16);
            this.label25.TabIndex = 5;
            this.label25.Text = "Rp 120.000";
            // 
            // btn_longPants1
            // 
            this.btn_longPants1.Location = new System.Drawing.Point(6, 220);
            this.btn_longPants1.Name = "btn_longPants1";
            this.btn_longPants1.Size = new System.Drawing.Size(114, 27);
            this.btn_longPants1.TabIndex = 4;
            this.btn_longPants1.Text = "Add To Cart";
            this.btn_longPants1.UseVisualStyleBackColor = true;
            this.btn_longPants1.Click += new System.EventHandler(this.btn_longPants1_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 181);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(114, 16);
            this.label26.TabIndex = 3;
            this.label26.Text = "Long Black Jeans";
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.btn_shoe3);
            this.panel_shoes.Controls.Add(this.btn_shoe2);
            this.panel_shoes.Controls.Add(this.label27);
            this.panel_shoes.Controls.Add(this.label28);
            this.panel_shoes.Controls.Add(this.label29);
            this.panel_shoes.Controls.Add(this.label30);
            this.panel_shoes.Controls.Add(this.pictureBox13);
            this.panel_shoes.Controls.Add(this.pictureBox14);
            this.panel_shoes.Controls.Add(this.label31);
            this.panel_shoes.Controls.Add(this.btn_shoe1);
            this.panel_shoes.Controls.Add(this.label32);
            this.panel_shoes.Controls.Add(this.pictureBox15);
            this.panel_shoes.Location = new System.Drawing.Point(12, 44);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(493, 291);
            this.panel_shoes.TabIndex = 17;
            this.panel_shoes.Visible = false;
            // 
            // btn_shoe3
            // 
            this.btn_shoe3.Location = new System.Drawing.Point(348, 220);
            this.btn_shoe3.Name = "btn_shoe3";
            this.btn_shoe3.Size = new System.Drawing.Size(114, 27);
            this.btn_shoe3.TabIndex = 13;
            this.btn_shoe3.Text = "Add To Cart";
            this.btn_shoe3.UseVisualStyleBackColor = true;
            this.btn_shoe3.Click += new System.EventHandler(this.btn_shoe3_Click);
            // 
            // btn_shoe2
            // 
            this.btn_shoe2.Location = new System.Drawing.Point(175, 220);
            this.btn_shoe2.Name = "btn_shoe2";
            this.btn_shoe2.Size = new System.Drawing.Size(114, 27);
            this.btn_shoe2.TabIndex = 12;
            this.btn_shoe2.Text = "Add To Cart";
            this.btn_shoe2.UseVisualStyleBackColor = true;
            this.btn_shoe2.Click += new System.EventHandler(this.btn_shoe2_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(369, 201);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(73, 16);
            this.label27.TabIndex = 11;
            this.label27.Text = "Rp 170.000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(196, 201);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(73, 16);
            this.label28.TabIndex = 9;
            this.label28.Text = "Rp 150.000";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(358, 181);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(104, 16);
            this.label29.TabIndex = 9;
            this.label29.Text = "Adidas NMD R1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(193, 181);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(85, 16);
            this.label30.TabIndex = 7;
            this.label30.Text = "Air Jordan 11";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(24, 201);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(73, 16);
            this.label31.TabIndex = 5;
            this.label31.Text = "Rp 120.000";
            // 
            // btn_shoe1
            // 
            this.btn_shoe1.Location = new System.Drawing.Point(6, 220);
            this.btn_shoe1.Name = "btn_shoe1";
            this.btn_shoe1.Size = new System.Drawing.Size(114, 27);
            this.btn_shoe1.TabIndex = 4;
            this.btn_shoe1.Text = "Add To Cart";
            this.btn_shoe1.UseVisualStyleBackColor = true;
            this.btn_shoe1.Click += new System.EventHandler(this.btn_shoe1_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(24, 181);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(78, 16);
            this.label32.TabIndex = 3;
            this.label32.Text = "Air Jordan 1";
            // 
            // panel_jewel
            // 
            this.panel_jewel.Controls.Add(this.btn_jewel3);
            this.panel_jewel.Controls.Add(this.btn_jewel2);
            this.panel_jewel.Controls.Add(this.label33);
            this.panel_jewel.Controls.Add(this.label34);
            this.panel_jewel.Controls.Add(this.label35);
            this.panel_jewel.Controls.Add(this.label36);
            this.panel_jewel.Controls.Add(this.pictureBox16);
            this.panel_jewel.Controls.Add(this.pictureBox17);
            this.panel_jewel.Controls.Add(this.label37);
            this.panel_jewel.Controls.Add(this.btn_jewel1);
            this.panel_jewel.Controls.Add(this.label38);
            this.panel_jewel.Controls.Add(this.pictureBox18);
            this.panel_jewel.Location = new System.Drawing.Point(12, 44);
            this.panel_jewel.Name = "panel_jewel";
            this.panel_jewel.Size = new System.Drawing.Size(493, 291);
            this.panel_jewel.TabIndex = 18;
            this.panel_jewel.Visible = false;
            // 
            // btn_jewel3
            // 
            this.btn_jewel3.Location = new System.Drawing.Point(348, 220);
            this.btn_jewel3.Name = "btn_jewel3";
            this.btn_jewel3.Size = new System.Drawing.Size(114, 27);
            this.btn_jewel3.TabIndex = 13;
            this.btn_jewel3.Text = "Add To Cart";
            this.btn_jewel3.UseVisualStyleBackColor = true;
            this.btn_jewel3.Click += new System.EventHandler(this.btn_jewel3_Click);
            // 
            // btn_jewel2
            // 
            this.btn_jewel2.Location = new System.Drawing.Point(175, 220);
            this.btn_jewel2.Name = "btn_jewel2";
            this.btn_jewel2.Size = new System.Drawing.Size(114, 27);
            this.btn_jewel2.TabIndex = 12;
            this.btn_jewel2.Text = "Add To Cart";
            this.btn_jewel2.UseVisualStyleBackColor = true;
            this.btn_jewel2.Click += new System.EventHandler(this.btn_jewel2_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(369, 201);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(73, 16);
            this.label33.TabIndex = 11;
            this.label33.Text = "Rp 170.000";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(196, 201);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(73, 16);
            this.label34.TabIndex = 9;
            this.label34.Text = "Rp 150.000";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(340, 181);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(150, 16);
            this.label35.TabIndex = 9;
            this.label35.Text = "Black Copper Necklace";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(193, 181);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(94, 16);
            this.label36.TabIndex = 7;
            this.label36.Text = "Silver Bracelet";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(24, 201);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(73, 16);
            this.label37.TabIndex = 5;
            this.label37.Text = "Rp 120.000";
            // 
            // btn_jewel1
            // 
            this.btn_jewel1.Location = new System.Drawing.Point(6, 220);
            this.btn_jewel1.Name = "btn_jewel1";
            this.btn_jewel1.Size = new System.Drawing.Size(114, 27);
            this.btn_jewel1.TabIndex = 4;
            this.btn_jewel1.Text = "Add To Cart";
            this.btn_jewel1.UseVisualStyleBackColor = true;
            this.btn_jewel1.Click += new System.EventHandler(this.btn_jewel1_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(24, 181);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(93, 16);
            this.label38.TabIndex = 3;
            this.label38.Text = "Aesthetic Ring";
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.tb_priceOthers);
            this.panel_others.Controls.Add(this.tb_nameOthers);
            this.panel_others.Controls.Add(this.label39);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.label43);
            this.panel_others.Controls.Add(this.btn_addOthers);
            this.panel_others.Controls.Add(this.label44);
            this.panel_others.Controls.Add(this.pbox_upload);
            this.panel_others.Location = new System.Drawing.Point(12, 44);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(493, 291);
            this.panel_others.TabIndex = 17;
            this.panel_others.Visible = false;
            // 
            // tb_priceOthers
            // 
            this.tb_priceOthers.Location = new System.Drawing.Point(239, 146);
            this.tb_priceOthers.Name = "tb_priceOthers";
            this.tb_priceOthers.Size = new System.Drawing.Size(100, 22);
            this.tb_priceOthers.TabIndex = 9;
            this.tb_priceOthers.TextChanged += new System.EventHandler(this.tb_priceOthers_TextChanged);
            this.tb_priceOthers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_priceOthers_KeyPress);
            // 
            // tb_nameOthers
            // 
            this.tb_nameOthers.Location = new System.Drawing.Point(239, 81);
            this.tb_nameOthers.Name = "tb_nameOthers";
            this.tb_nameOthers.Size = new System.Drawing.Size(100, 22);
            this.tb_nameOthers.TabIndex = 8;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(237, 127);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(66, 16);
            this.label39.TabIndex = 7;
            this.label39.Text = "Item Price";
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(225, 9);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(114, 27);
            this.btn_upload.TabIndex = 6;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(237, 62);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(72, 16);
            this.label43.TabIndex = 5;
            this.label43.Text = "Item Name";
            // 
            // btn_addOthers
            // 
            this.btn_addOthers.Enabled = false;
            this.btn_addOthers.Location = new System.Drawing.Point(225, 187);
            this.btn_addOthers.Name = "btn_addOthers";
            this.btn_addOthers.Size = new System.Drawing.Size(127, 27);
            this.btn_addOthers.TabIndex = 4;
            this.btn_addOthers.Text = "Add To Cart";
            this.btn_addOthers.UseVisualStyleBackColor = true;
            this.btn_addOthers.Click += new System.EventHandler(this.btn_addOthers_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(108, 14);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(93, 16);
            this.label44.TabIndex = 3;
            this.label44.Text = "Upload Image";
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(853, 341);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 19;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::TH09_Edward_Geraldo.Properties.Resources.kjw_landscape;
            this.pictureBox19.Location = new System.Drawing.Point(67, 341);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(387, 181);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 10;
            this.pictureBox19.TabStop = false;
            // 
            // pbox_upload
            // 
            this.pbox_upload.Location = new System.Drawing.Point(93, 46);
            this.pbox_upload.Name = "pbox_upload";
            this.pbox_upload.Size = new System.Drawing.Size(126, 168);
            this.pbox_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_upload.TabIndex = 0;
            this.pbox_upload.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::TH09_Edward_Geraldo.Properties.Resources.cream_trousers;
            this.pictureBox10.Location = new System.Drawing.Point(348, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(126, 168);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 8;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::TH09_Edward_Geraldo.Properties.Resources.blue_jeans;
            this.pictureBox11.Location = new System.Drawing.Point(175, 0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(126, 168);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 6;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::TH09_Edward_Geraldo.Properties.Resources.black_jeans;
            this.pictureBox12.Location = new System.Drawing.Point(3, 0);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(126, 168);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::TH09_Edward_Geraldo.Properties.Resources.Adidas_NMD_R1;
            this.pictureBox13.Location = new System.Drawing.Point(348, 0);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(126, 168);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 8;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::TH09_Edward_Geraldo.Properties.Resources.Air_Jordan_11;
            this.pictureBox14.Location = new System.Drawing.Point(175, 0);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(126, 168);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 6;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::TH09_Edward_Geraldo.Properties.Resources.Air_Jordan_1;
            this.pictureBox15.Location = new System.Drawing.Point(3, 0);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(126, 168);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::TH09_Edward_Geraldo.Properties.Resources.necklace;
            this.pictureBox16.Location = new System.Drawing.Point(348, 0);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(126, 168);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 8;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::TH09_Edward_Geraldo.Properties.Resources.bracelet;
            this.pictureBox17.Location = new System.Drawing.Point(175, 0);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(126, 168);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 6;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::TH09_Edward_Geraldo.Properties.Resources.ring;
            this.pictureBox18.Location = new System.Drawing.Point(3, 0);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(126, 168);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::TH09_Edward_Geraldo.Properties.Resources.white_pants;
            this.pictureBox7.Location = new System.Drawing.Point(348, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(126, 168);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 8;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::TH09_Edward_Geraldo.Properties.Resources.cream_pants;
            this.pictureBox8.Location = new System.Drawing.Point(175, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(126, 168);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 6;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::TH09_Edward_Geraldo.Properties.Resources.black_pants;
            this.pictureBox9.Location = new System.Drawing.Point(3, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(126, 168);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TH09_Edward_Geraldo.Properties.Resources.Cream_Shirt;
            this.pictureBox4.Location = new System.Drawing.Point(348, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(126, 168);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::TH09_Edward_Geraldo.Properties.Resources.green_shirt;
            this.pictureBox5.Location = new System.Drawing.Point(175, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(126, 168);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 6;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::TH09_Edward_Geraldo.Properties.Resources.baju_biru;
            this.pictureBox6.Location = new System.Drawing.Point(3, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(126, 168);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::TH09_Edward_Geraldo.Properties.Resources.kim_ji_won_black_tshirt;
            this.pictureBox3.Location = new System.Drawing.Point(348, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(126, 168);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TH09_Edward_Geraldo.Properties.Resources.kim_ji_won_airism;
            this.pictureBox2.Location = new System.Drawing.Point(175, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(126, 168);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TH09_Edward_Geraldo.Properties.Resources.kim_ji_won_tshirt;
            this.pictureBox1.Location = new System.Drawing.Point(3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(126, 168);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 593);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_longPants);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_jewel);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_subTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_total);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainForm";
            this.Text = "mainForm";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_total)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            this.panel_longPants.ResumeLayout(false);
            this.panel_longPants.PerformLayout();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            this.panel_jewel.ResumeLayout(false);
            this.panel_jewel.PerformLayout();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_upload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelrysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_total;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_subTotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.Button btn_tshirt1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_tshirt3;
        private System.Windows.Forms.Button btn_tshirt2;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_shirt3;
        private System.Windows.Forms.Button btn_shirt2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_shirt1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_shortpant3;
        private System.Windows.Forms.Button btn_shortpant2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btn_shortpant1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel_longPants;
        private System.Windows.Forms.Button btn_longPants3;
        private System.Windows.Forms.Button btn_longPants2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btn_longPants1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_shoe3;
        private System.Windows.Forms.Button btn_shoe2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btn_shoe1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Panel panel_jewel;
        private System.Windows.Forms.Button btn_jewel3;
        private System.Windows.Forms.Button btn_jewel2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button btn_jewel1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button btn_addOthers;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.PictureBox pbox_upload;
        private System.Windows.Forms.TextBox tb_priceOthers;
        private System.Windows.Forms.TextBox tb_nameOthers;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.PictureBox pictureBox19;
    }
}

